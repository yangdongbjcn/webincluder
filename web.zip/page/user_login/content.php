<div class='container-fluid'>
<div class='row-fluid'>
  <div class='col-sm-3'></div>
  <div class='col-sm-6'>
      
    <div>
      <ul class='nav nav-pills pull-right'>
        <li><a href='https://github.com/yangdongbjcn/webpage-includer'>Visit in GitHub</a></li>
      </ul>
      <h3>Webpage Includer</h3>
    </div>

    <div class='well center'>
      <p>
      Webpage Includer tries to seperate html pages into components, which include their own JavaScript and CSS codes. Webpage Includer uses PHP include function to reuse these page components.
      </p>
      <div class='input-group'>
        <span class='input-group-addon'>User Name</span>
        <input autofocus class='form-control' type='text'/>
      </div>

      <div class='input-group ydbj_layout_margin_top_s'>
        <span class='input-group-addon'>Password</span>
        <input name='u_psd' id='u_psd' class='form-control' type='password'/>
      </div>

      <button name='submit' id='submit' class='btn btn-2 ydbj_layout_margin_top_s ydbj_layout_width_pixels_xl ydbj_layout_center'>Sign In</button> 
    </div><!--/well-->

  </div>
 
  <div class='col-sm-3'></div>
</div>
</div>


  

