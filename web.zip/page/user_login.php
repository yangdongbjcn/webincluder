<?php
	include('../basepath.php');	 
	include('../common/includes/begin.php');
?>
	<link rel='stylesheet' href='<?php echo $g_page ?>user_login/content.css'>
	<script type='text/javascript' src='<?php echo $g_page ?>user_login/content.js'></script>
<?php
	include('user_login/content.php');
	include('../common/includes/end.php');
?>