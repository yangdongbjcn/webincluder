<?php 
	include('../../../basepath.php');	 
	include('../../../common/includes/begin.php'); 
	include('../../../common/includes/menu_top.php');
?>
	<link rel="stylesheet" href="<?php echo $g_subsubpage ?>index/content.css">
	<script type="text/javascript" src="<?php echo $g_subsubpage ?>index/content.js"></script>
<?php
	include("index/content.php");
	include('../../../common/includes/footer.php'); 
	include('../../../common/includes/end.php');
?>
