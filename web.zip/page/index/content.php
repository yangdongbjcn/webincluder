
<form class='form-horizontal'>
	<fieldset>
		<div>
			<table class='table table-bordered'>  
				<tbody>
					<tr>
						<td>Name</td>
						<td>Webpage Includer</td>
					</tr>
					<tr>
						<td>Contributer</td>
						<td>YANGDONGBJCN</td>
					</tr>
					<tr>
						<td>Website</td>
						<td><a href='https://github.com/yangdongbjcn/webpage-includer'>https://github.com/yangdongbjcn/webpage-includer</a></td>
					</tr>
				</tbody>
			</table>
		</div>
	</fieldset>
</form>
