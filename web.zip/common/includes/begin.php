<!DOCTYPE html>
<html lang='en'>
<head>
	<meta charset='utf-8'>

	<meta http-equiv='X-UA-Compatible' content='IE=9' />

	<title>Webpage Includer</title>

	<link rel='stylesheet' href='<?php echo $g_resc ?>bootstrap/css/bootstrap.css'>

  <link rel='shortcut icon' href='<?php echo $g_resc ?>img/wi64.ico'>

  <script type='text/javascript' src='<?php echo $g_resc ?>jquery/jquery.js'></script>

</head>

<body>

<script type='text/javascript' src='<?php echo $g_root ?>basepath.js'></script>

<link rel='stylesheet' href='<?php echo $g_incl ?>/ydbj_layout_margin.css'>
<link rel='stylesheet' href='<?php echo $g_incl ?>/ydbj_layout_width.css'>
