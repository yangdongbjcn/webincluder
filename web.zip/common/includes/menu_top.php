<!-- container-fluid -->
<div class='container-fluid'>
<!-- row-fluid -->
<div class='row-fluid'>

	<!-- top menu starts -->
	<div class='navbar navbar-default' role='navigation'>
			
		<ul class='nav navbar-nav'>
			<li><a href='https://github.com/yangdongbjcn/webpage-includer'>Visit in GitHub</a></li>

			<li class='drop-down' >
				<a class='dropdown-toggle' data-toggle='dropdown'>
					<span class='icon-user'></span>
					User Help
					<span class='caret'></span>
				</a>
				<ul class='dropdown-menu'>
					<li><a href='https://github.com/yangdongbjcn/webpage-includer'>Visit in GitHub</a></li>
				</ul>
			</li>
		</ul>
		
	</div>
	<!-- top menu ends -->
</div>
<!-- row-fluid -->

<script src="<?php echo $g_comn ?>includes/menu_top.js"></script>