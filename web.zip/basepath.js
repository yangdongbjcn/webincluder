var t_url = location.href.split('web');

var g_var = {}; 
g_var.g_root = t_url[0] + 'web/';

g_var.g_page = g_var.g_root + 'page/';
g_var.g_subpage = g_var.g_page + 'subpage/';
g_var.g_subsubpage = g_var.g_subpage + 'subsubpage/';

